// ============================================================
//  DATA.JS — Edit this file to update your portfolio content
//  Structure is self-explanatory. Don't touch index.html or
//  style.css unless you want to change layout / design.
// ============================================================

const DATA = {

  // ── PERSONAL INFO ────────────────────────────────────────
  name:     "Mahirul Islam",
  role:     "QA Engineer & AI Developer",
  location: "Saitama / Tokyo, Japan",
  email:    "YOUR_EMAIL@gmail.com",
  linkedin: "linkedin.com/in/YOUR_LINKEDIN",
  github:   "github.com/Slyyoursenpai",
  cv:       "./cv.pdf",               // path to your CV file, or a Google Drive link
  status:   "Available",             // shown in the hero pill

  // short bio shown in hero
  heroBio: "Breaking systems so users don't have to. MSc candidate at Tokyo International University, with 1.5+ years building test infrastructure and shipping lightweight AI for constrained devices.",

  // ── STATS (hero right panel) ─────────────────────────────
  stats: [
    { label: "Experience",         sub: "SQA Engineering",                    value: "1.5y+" },
    { label: "Published Research", sub: "IET Cyber-Physical Systems",         value: "1"     },
    { label: "Current study",      sub: "Digital Business & Innovation · TIU", value: "MSc"  },
  ],

  // ── ABOUT SECTION ────────────────────────────────────────
  about: {
    // Each string becomes a paragraph
    paragraphs: [
      "I'm a QA Engineer and AI developer currently based in <strong>Saitama, Japan</strong>, pursuing an MSc in Digital Business & Innovation at <strong>Tokyo International University</strong>. My engineering background is in software quality assurance, where I built test automation infrastructure using Selenium, Java, and BDD frameworks.",
      "On the research side, I published a paper in <strong>IET Cyber-Physical Systems (2024)</strong> on mobile cataract detection — a lightweight CNN deployed via TensorFlow Lite on Android, demonstrating that real-world constraints are a design parameter, not an afterthought.",
      "I'm actively targeting <strong>QA, SDET, and tech roles at English-friendly companies in Japan</strong> — global tech firms, foreign-affiliated companies, and multinational consultancies. I bring both the systematic mindset of a tester and the curiosity of a builder.",
    ],
    // Sidebar cards — add/remove freely
    sidebar: [
      {
        label: "Currently",
        body:  "<strong>MSc Student · TIU Ikebukuro</strong>Digital Business & Innovation",
      },
      {
        label: "Research interests",
        body:  "Lightweight ML · Edge AI<br>Medical Computer Vision<br>RAG & On-device Inference",
      },
      {
        label: "Target employers",
        body:  "Rakuten · Mercari · Amazon Japan<br>Microsoft Japan · MNCs<br>English-friendly global tech",
      },
      {
        label: "Languages",
        body:  "English (professional) · Bengali (native)<br>Japanese N5 → actively studying",
      },
    ],
  },

  // ── EXPERIENCE ───────────────────────────────────────────
  // Add new jobs at the top of the array (newest first)
  experience: [
    {
      type:    "SQA Engineer",
      period:  "2022 — 2024",
      org:     "Tekarsh",
      title:   "Software Quality Assurance Engineer",
      company: "Tekarsh · Embedded at MarginEdge · Remote",
      bullets: [
        "Built and maintained Selenium + Java test suites with BDD (Cucumber/Gherkin) covering core product flows end-to-end",
        "Designed and executed API test cases using Postman; integrated into regression pipelines for continuous coverage",
        "Collaborated in Agile sprints — owned bug triage, test planning, and release sign-off processes",
        "Established test documentation standards that reduced regression cycle time and improved onboarding",
        "Worked directly with product and engineering teams in a US-based startup environment",
      ],
      tags: ["Selenium/Java", "BDD/Cucumber", "Postman", "Agile/Scrum", "JIRA", "Test Planning"],
    },
    {
      type:    "QA Intern",
      period:  "2022",
      org:     "a1qa",
      title:   "QA Engineer Intern",
      company: "a1qa · Remote",
      bullets: [
        "Performed functional, regression, and exploratory testing across web applications",
        "Authored test cases, maintained test documentation, and participated in defect reporting workflows",
        "Gained hands-on exposure to structured QA processes within an international team",
      ],
      tags: ["Manual Testing", "Test Case Design", "Bug Reporting", "Regression Testing"],
    },
  ],

  // ── RESEARCH ─────────────────────────────────────────────
  papers: [
    {
      year:   "2024",
      badge:  "IET Cyber-Physical Systems · Peer-reviewed",
      title:  "Mobile Cataract Detection via Lightweight CNN on Edge Devices",
      desc:   "Designed and deployed a lightweight convolutional neural network for cataract detection, optimised for Android deployment via TensorFlow Lite. Achieved clinically useful accuracy on constrained hardware — making ophthalmic screening accessible without specialist equipment. Associated Android app: <strong>I-Scan</strong>.",
      tags:   ["TensorFlow Lite", "CNN", "Android", "Medical AI", "Edge Inference", "Kotlin"],
      link:   "",   // add DOI / arXiv link if you have one
    },
  ],

  // Work-in-progress research card (leave empty string to hide it)
  wip: {
    label: "In Progress · MSc Research Direction",
    title: "On-device RAG & Offline AI Pipelines",
    desc:  "Exploring offline RAG pipeline design — local embeddings (MiniLM, MediaPipe), vector stores (ChromaDB, LanceDB), and on-device LLM inference (Ollama, llama.cpp). Target: Android architecture via Jetpack Compose + ONNX Runtime.",
  },

  // ── PROJECTS ─────────────────────────────────────────────
  // Add new projects anywhere — numbering is auto-generated
  projects: [
    {
      title:     "I-Scan",
      sub:       "Mobile cataract detection app",
      desc:      "Android app deploying a TFLite CNN for real-time cataract screening. Jetpack Compose UI, Room DB for local history. Published — IET Cyber-Physical Systems 2024.",
      tags:      ["Android", "TFLite", "Jetpack Compose", "Room DB"],
      link:      "https://github.com/Slyyoursenpai",
      linkLabel: "View on GitHub",
    },
    {
      title:     "NoteAI",
      sub:       "AI-powered smart notebook",
      desc:      "React app with Claude API integration for intelligent note-taking, AI-assisted summarisation, and Q&A over personal notes.",
      tags:      ["React", "Claude API", "RAG"],
      link:      "https://github.com/Slyyoursenpai",
      linkLabel: "View on GitHub",
    },
    {
      title:     "Player Behaviour Analytics",
      sub:       "DB design · PostgreSQL",
      desc:      "Game store analytics platform — full business case (PESTEL/SWOT), UML use-case diagrams, data flow, and single-database PostgreSQL architecture for telemetry at scale.",
      tags:      ["PostgreSQL", "UML", "DB Design", "PESTEL"],
      link:      "",
      linkLabel: "Academic · TIU",
    },
    {
      title:     "Playwright E2E Suite",
      sub:       "Modern QA portfolio project",
      desc:      "E2E test framework built with Playwright + TypeScript demonstrating current-stack QA proficiency. CI/CD integrated, page object model, reporting.",
      tags:      ["Playwright", "TypeScript", "CI/CD", "POM"],
      link:      "https://github.com/Slyyoursenpai",
      linkLabel: "In progress",
    },
    {
      title:     "Self-hosted Media Stack",
      sub:       "Remote access infrastructure",
      desc:      "Personal media and file access stack — Jellyfin, Tailscale, FileBrowser/Syncthing. Set up for remote access from Japan to home server.",
      tags:      ["Jellyfin", "Tailscale", "Syncthing", "Self-hosted"],
      link:      "",
      linkLabel: "Personal infra",
    },
    {
      title:     "This Portfolio",
      sub:       "Vanilla HTML · CSS · JS",
      desc:      "Built without a framework. Dark editorial aesthetic, Syne + DM Mono typefaces, scroll-reveal animations. Data-driven — all content lives in data.js.",
      tags:      ["HTML", "CSS", "JavaScript"],
      link:      "https://github.com/Slyyoursenpai",
      linkLabel: "View source",
    },
  ],

  // ── SKILLS / STACK ───────────────────────────────────────
  // Add/remove categories and items freely
  skills: [
    {
      category: "QA / Testing",
      items: ["Selenium", "Playwright", "Postman", "Cucumber", "BDD/Gherkin", "JIRA", "TestNG"],
    },
    {
      category: "Languages",
      items: ["Java", "Python", "TypeScript", "JavaScript", "Kotlin", "SQL"],
    },
    {
      category: "AI / ML",
      items: ["TensorFlow Lite", "ONNX Runtime", "ChromaDB", "LanceDB", "RAG", "Claude API"],
    },
    {
      category: "Frontend / Mobile",
      items: ["React", "Android", "Jetpack Compose", "HTML/CSS", "Tailwind"],
    },
    {
      category: "Data / Backend",
      items: ["PostgreSQL", "Firebase", "Room DB", "REST APIs", "SQLite"],
    },
    {
      category: "Tools / Infra",
      items: ["Git / GitHub", "GitHub Actions", "Tailscale", "Linux", "VS Code"],
    },
  ],

  // ── CONTACT — open to ────────────────────────────────────
  openTo: [
    "QA Engineer / SDET",
    "Test Automation Engineer",
    "Junior AI/ML Engineer",
    "Android Developer (QA-adjacent)",
    "Research Collaborations",
  ],

  contactNote: "Full-time roles in Tokyo / Saitama area. Remote-first international teams also welcome.",

};
